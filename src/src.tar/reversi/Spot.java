package reversi;

public class Spot {
	public int x;
	public int y;
	public boolean empty;
	public Spot(int x, int y){
		this.x = x;
		this.y = y;
	}
}
