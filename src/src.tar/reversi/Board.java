package reversi;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.*;

import reversi.Tile.State;

public class Board extends JFrame {
	public static final int SIZE = 8;
	Tile[][] tiles = new Tile[SIZE][SIZE];
	private boolean playable = true;
	private Game game;
	
	/**
	 * creates a board with tiles in the default positions
	 */
	public Board(Game game){	
		this.game = game;
		//GUI setup
		setSize(500, 500);
		setResizable(false);
		setLayout(new GridLayout(SIZE,SIZE));
		getContentPane().setBackground(Color.white);
		
		//Layout tiles
		for (int i = 0; i < SIZE; i++) {
			for (int j = 0; j < SIZE; j++) {
				tiles[i][j] = new Tile(this,i,j);
				add(tiles[i][j]);
			}
		}
		
		//Middle of Board
		final int middle = SIZE / 2;
		
		//Setup initial tiles
		tiles[middle - 1][middle - 1].setState(Tile.State.WHITE);
		tiles[middle - 1][middle].setState(Tile.State.BLACK);
		tiles[middle][middle].setState(Tile.State.WHITE);
		tiles[middle][middle - 1].setState(Tile.State.BLACK);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
		
	public void tileClick(Tile tile) {
		if (playable) {
			game.makeMove(tile.getXCoord(), tile.getYCoord());
		}
	}

	/**
	 * 
	 * @param x x position of tile to return
	 * @param y y position of tile to return
	 * @return
	 */
	public Tile getTile(int x, int y){
		return tiles[x][y];
	}
	
	public void setTile(int x, int y, State color){
		tiles[x][y].setState(color);
	}
	public void debugPrint(){
		for (int x = 0; x < 8; x++) {
		    for (int y = 0; y < 8; y++) {
		    	if(tiles[y][x].getState().equals(State.BLANK))
					System.out.print("*");
				if(tiles[y][x].getState().equals(State.BLACK))
					System.out.print("X");
				if(tiles[y][x].getState().equals(State.WHITE))
				    System.out.print("O");
		    }
		    System.out.println();
		}
	}
	

	/**
	 * flips a tile at the given location
	 * @param x x position of tile to flip
	 * @param y y position of tile to flip
	 */
	public void flipTile(int x, int y){
		tiles[x][y].flip();
	}
	
	/**
	 * O(n^2), try not to use
	 */
	public boolean equals(Object obj){
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		for(int x = 0; x<8; x++){
			for(int y = 0; y<8; y++){
				Board other = (Board) obj;
				if (this.getTile(x,y) == null) {
					if (other.getTile(x,y) != null)
						return false;
				}else if (!getTile(x,y).equals(other.getTile(x,y)))
					return false;
				
			}
		}return true;
	}
}
